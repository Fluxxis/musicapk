package com.example.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT_AUDIO = 6201;

    private final int bg = Color.rgb(7, 7, 10);
    private final int card = Color.rgb(21, 21, 28);
    private final int cardSoft = Color.rgb(31, 31, 41);
    private final int text = Color.rgb(245, 245, 247);
    private final int muted = Color.rgb(154, 154, 162);
    private final int accent = Color.rgb(250, 45, 85);

    private LinearLayout root;
    private LinearLayout tabRow;
    private LinearLayout content;
    private TextView titleView;
    private TextView subtitleView;
    private TextView trackTitle;
    private TextView trackSubtitle;
    private TextView timeStart;
    private TextView timeEnd;
    private SeekBar seekBar;
    private Button playButton;
    private Button bottomButton;

    private final ArrayList<Track> tracks = new ArrayList<Track>();
    private int currentIndex = -1;
    private MediaPlayer player;
    private boolean userSeeking = false;
    private final Handler handler = new Handler();

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            handler.postDelayed(this, 700);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(bg);
        window.setNavigationBarColor(bg);
        buildUi();
        showPlayer();
        handler.post(tick);
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(14), dp(18), dp(16));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        titleView = new TextView(this);
        titleView.setText("Ready Music");
        titleView.setTextColor(text);
        titleView.setTextSize(30);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(titleView);

        subtitleView = new TextView(this);
        subtitleView.setText("Native Java player. Clean, dark, fast.");
        subtitleView.setTextColor(muted);
        subtitleView.setTextSize(14);
        subtitleView.setPadding(0, dp(4), 0, dp(14));
        header.addView(subtitleView);

        tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setGravity(Gravity.CENTER);
        root.addView(tabRow, new LinearLayout.LayoutParams(-1, dp(48)));

        addTab("Player", true, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPlayer();
            }
        });
        addTab("Library", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLibrary();
            }
        });
        addTab("Import", false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImport();
            }
        });

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(false);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(-1, 0, 1);
        scrollLp.topMargin = dp(14);
        root.addView(scrollView, scrollLp);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(content, new ScrollView.LayoutParams(-1, -2));

        bottomButton = new Button(this);
        bottomButton.setAllCaps(false);
        bottomButton.setText("Import music");
        bottomButton.setTextColor(Color.WHITE);
        bottomButton.setTextSize(16);
        bottomButton.setTypeface(Typeface.DEFAULT_BOLD);
        bottomButton.setBackground(round(accent, 24));
        bottomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImportPicker();
            }
        });
        addPressAnimation(bottomButton);
        LinearLayout.LayoutParams bottomLp = new LinearLayout.LayoutParams(-1, dp(56));
        bottomLp.topMargin = dp(12);
        root.addView(bottomButton, bottomLp);
    }

    private void addTab(String label, boolean active, View.OnClickListener listener) {
        TextView tab = new TextView(this);
        tab.setText(label);
        tab.setGravity(Gravity.CENTER);
        tab.setTextSize(14);
        tab.setTypeface(Typeface.DEFAULT_BOLD);
        tab.setTextColor(active ? Color.BLACK : text);
        tab.setBackground(round(active ? Color.WHITE : Color.rgb(28, 28, 36), 20));
        tab.setOnClickListener(listener);
        addPressAnimation(tab);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(42), 1);
        lp.leftMargin = dp(4);
        lp.rightMargin = dp(4);
        tabRow.addView(tab, lp);
    }

    private void selectTab(int index) {
        for (int i = 0; i < tabRow.getChildCount(); i++) {
            TextView tab = (TextView) tabRow.getChildAt(i);
            boolean active = i == index;
            tab.setTextColor(active ? Color.BLACK : text);
            tab.setBackground(round(active ? Color.WHITE : Color.rgb(28, 28, 36), 20));
            tab.animate().alpha(active ? 1f : 0.78f).setDuration(160).start();
        }
    }

    private void showPlayer() {
        selectTab(0);
        content.removeAllViews();
        titleView.setText("Ready Music");
        subtitleView.setText("Minimal player with import, queue and smooth controls.");
        bottomButton.setText("Import music");

        FrameLayout art = new FrameLayout(this);
        GradientDrawable artBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(42, 42, 54), accent, Color.rgb(12, 12, 18)});
        artBg.setCornerRadius(dp(34));
        art.setBackground(artBg);
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(-1, dp(310));
        content.addView(art, artLp);

        TextView note = new TextView(this);
        note.setText("♪");
        note.setTextColor(Color.WHITE);
        note.setTextSize(86);
        note.setGravity(Gravity.CENTER);
        art.addView(note, new FrameLayout.LayoutParams(-1, -1));
        note.animate().scaleX(1.04f).scaleY(1.04f).alpha(0.88f).setDuration(900).withEndAction(new Runnable() {
            @Override
            public void run() {
                note.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(900).start();
            }
        }).start();

        LinearLayout infoCard = cardContainer();
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, -2);
        infoLp.topMargin = dp(16);
        content.addView(infoCard, infoLp);

        trackTitle = new TextView(this);
        trackTitle.setTextColor(text);
        trackTitle.setTextSize(24);
        trackTitle.setTypeface(Typeface.DEFAULT_BOLD);
        trackTitle.setText(currentTrackTitle());
        infoCard.addView(trackTitle);

        trackSubtitle = new TextView(this);
        trackSubtitle.setTextColor(muted);
        trackSubtitle.setTextSize(14);
        trackSubtitle.setPadding(0, dp(5), 0, dp(18));
        trackSubtitle.setText(tracks.isEmpty() ? "Import audio files to start listening" : "Local file from your device");
        infoCard.addView(trackSubtitle);

        seekBar = new SeekBar(this);
        seekBar.setMax(1000);
        seekBar.setProgress(0);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && player != null) {
                    int duration = player.getDuration();
                    int target = (int) ((progress / 1000f) * duration);
                    timeStart.setText(formatTime(target));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                userSeeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (player != null) {
                    int duration = player.getDuration();
                    int target = (int) ((seekBar.getProgress() / 1000f) * duration);
                    player.seekTo(target);
                }
                userSeeking = false;
            }
        });
        infoCard.addView(seekBar, new LinearLayout.LayoutParams(-1, dp(38)));

        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        timeStart = smallText("0:00");
        timeEnd = smallText("0:00");
        times.addView(timeStart, new LinearLayout.LayoutParams(0, -2, 1));
        timeEnd.setGravity(Gravity.RIGHT);
        times.addView(timeEnd, new LinearLayout.LayoutParams(0, -2, 1));
        infoCard.addView(times);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams controlsLp = new LinearLayout.LayoutParams(-1, dp(72));
        controlsLp.topMargin = dp(12);
        infoCard.addView(controls, controlsLp);

        Button prev = controlButton("‹‹");
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousTrack();
            }
        });
        controls.addView(prev, new LinearLayout.LayoutParams(dp(64), dp(56)));

        playButton = controlButton(isPlaying() ? "Pause" : "Play");
        playButton.setBackground(round(accent, 28));
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePlay();
            }
        });
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(dp(116), dp(56));
        playLp.leftMargin = dp(12);
        playLp.rightMargin = dp(12);
        controls.addView(playButton, playLp);

        Button next = controlButton("››");
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextTrack();
            }
        });
        controls.addView(next, new LinearLayout.LayoutParams(dp(64), dp(56)));

        addFeatureCards();
        updateProgress();
    }

    private void showLibrary() {
        selectTab(1);
        content.removeAllViews();
        titleView.setText("Library");
        subtitleView.setText(tracks.size() + " imported track" + (tracks.size() == 1 ? "" : "s"));
        bottomButton.setText("Add more music");

        if (tracks.isEmpty()) {
            LinearLayout empty = cardContainer();
            TextView title = bigText("No music imported");
            TextView desc = normalText("Open the Import tab and choose audio files from your device. The app keeps access through Android document picker.");
            empty.addView(title);
            empty.addView(desc);
            content.addView(empty, new LinearLayout.LayoutParams(-1, -2));
            return;
        }

        for (int i = 0; i < tracks.size(); i++) {
            final int index = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(16), dp(12), dp(14), dp(12));
            item.setBackground(round(index == currentIndex ? Color.rgb(47, 29, 39) : card, 22));
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-1, dp(78));
            itemLp.bottomMargin = dp(10);
            content.addView(item, itemLp);

            TextView icon = new TextView(this);
            icon.setText(index == currentIndex && isPlaying() ? "▶" : "♪");
            icon.setTextColor(Color.WHITE);
            icon.setTextSize(24);
            icon.setGravity(Gravity.CENTER);
            icon.setBackground(round(accent, 18));
            item.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

            LinearLayout texts = new LinearLayout(this);
            texts.setOrientation(LinearLayout.VERTICAL);
            texts.setPadding(dp(14), 0, 0, 0);
            TextView name = new TextView(this);
            name.setText(tracks.get(i).title);
            name.setTextColor(text);
            name.setTextSize(16);
            name.setSingleLine(true);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            TextView meta = new TextView(this);
            meta.setText(index == currentIndex ? "Current track" : "Tap to play");
            meta.setTextColor(muted);
            meta.setTextSize(13);
            texts.addView(name);
            texts.addView(meta);
            item.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    playTrack(index);
                    showPlayer();
                }
            });
            addPressAnimation(item);
        }
    }

    private void showImport() {
        selectTab(2);
        content.removeAllViews();
        titleView.setText("Import");
        subtitleView.setText("Choose local music files. No accounts. No cloud.");
        bottomButton.setText("Choose audio files");

        LinearLayout cardOne = cardContainer();
        TextView t1 = bigText("Import from device");
        TextView d1 = normalText("Use Android file picker and select one or many audio files. MP3, WAV, M4A and other formats depend on your device codec support.");
        cardOne.addView(t1);
        cardOne.addView(d1);
        Button choose = new Button(this);
        choose.setAllCaps(false);
        choose.setText("Open file picker");
        choose.setTextColor(Color.WHITE);
        choose.setTextSize(16);
        choose.setTypeface(Typeface.DEFAULT_BOLD);
        choose.setBackground(round(accent, 24));
        choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImportPicker();
            }
        });
        addPressAnimation(choose);
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(-1, dp(54));
        chooseLp.topMargin = dp(18);
        cardOne.addView(choose, chooseLp);
        content.addView(cardOne, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout cardTwo = cardContainer();
        LinearLayout.LayoutParams twoLp = new LinearLayout.LayoutParams(-1, -2);
        twoLp.topMargin = dp(14);
        TextView t2 = bigText("What is included");
        cardTwo.addView(t2);
        cardTwo.addView(bullet("Dark native interface"));
        cardTwo.addView(bullet("Rounded cards and bottom action button"));
        cardTwo.addView(bullet("Player controls, queue and seek bar"));
        cardTwo.addView(bullet("Smooth press animations"));
        content.addView(cardTwo, twoLp);
    }

    private void addFeatureCards() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.topMargin = dp(14);
        content.addView(row, rowLp);

        row.addView(featureCard("Library", "Imported tracks stay in the current session and play from secure Android URIs."));
        row.addView(featureCard("Design", "Dark background, soft cards, readable text and compact controls."));
        row.addView(featureCard("Native", "Pure Java Activity. No XML layouts, no external UI libraries."));
    }

    private View featureCard(String title, String desc) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(round(cardSoft, 22));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        box.setLayoutParams(lp);
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(text);
        titleView.setTextSize(16);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        TextView descView = new TextView(this);
        descView.setText(desc);
        descView.setTextColor(muted);
        descView.setTextSize(13);
        descView.setPadding(0, dp(5), 0, 0);
        box.addView(titleView);
        box.addView(descView);
        return box;
    }

    private void openImportPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, REQ_IMPORT_AUDIO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_IMPORT_AUDIO || resultCode != RESULT_OK || data == null) {
            return;
        }
        int added = 0;
        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int i = 0; i < clipData.getItemCount(); i++) {
                Uri uri = clipData.getItemAt(i).getUri();
                if (addTrack(uri)) {
                    added++;
                }
            }
        } else if (data.getData() != null) {
            if (addTrack(data.getData())) {
                added++;
            }
        }
        if (added > 0 && currentIndex < 0) {
            currentIndex = 0;
        }
        Toast.makeText(this, "Imported: " + added, Toast.LENGTH_SHORT).show();
        showLibrary();
    }

    private boolean addTrack(Uri uri) {
        if (uri == null) {
            return false;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        String name = queryName(uri);
        if (name == null || name.trim().length() == 0) {
            name = "Audio track " + (tracks.size() + 1);
        }
        tracks.add(new Track(name, uri));
        return true;
    }

    private String queryName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    return cursor.getString(index);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return null;
    }

    private void togglePlay() {
        if (tracks.isEmpty()) {
            openImportPicker();
            return;
        }
        if (currentIndex < 0) {
            currentIndex = 0;
        }
        if (player == null) {
            playTrack(currentIndex);
            return;
        }
        if (player.isPlaying()) {
            player.pause();
        } else {
            player.start();
        }
        refreshPlayButton();
    }

    private void playTrack(int index) {
        if (index < 0 || index >= tracks.size()) {
            return;
        }
        currentIndex = index;
        releasePlayer();
        try {
            player = MediaPlayer.create(this, tracks.get(index).uri);
            if (player == null) {
                Toast.makeText(this, "Cannot play this file", Toast.LENGTH_SHORT).show();
                return;
            }
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    nextTrack();
                }
            });
            player.start();
            updateTrackLabels();
            refreshPlayButton();
        } catch (Exception e) {
            Toast.makeText(this, "Playback error", Toast.LENGTH_SHORT).show();
        }
    }

    private void nextTrack() {
        if (tracks.isEmpty()) {
            return;
        }
        int next = currentIndex + 1;
        if (next >= tracks.size()) {
            next = 0;
        }
        playTrack(next);
    }

    private void previousTrack() {
        if (tracks.isEmpty()) {
            return;
        }
        int prev = currentIndex - 1;
        if (prev < 0) {
            prev = tracks.size() - 1;
        }
        playTrack(prev);
    }

    private void updateProgress() {
        if (player == null || seekBar == null || userSeeking) {
            return;
        }
        try {
            int duration = player.getDuration();
            int position = player.getCurrentPosition();
            if (duration > 0) {
                int progress = (int) ((position * 1000L) / duration);
                seekBar.setProgress(progress);
                timeStart.setText(formatTime(position));
                timeEnd.setText(formatTime(duration));
            }
        } catch (Exception ignored) {
        }
    }

    private void updateTrackLabels() {
        if (trackTitle != null) {
            trackTitle.setText(currentTrackTitle());
        }
        if (trackSubtitle != null) {
            trackSubtitle.setText(tracks.isEmpty() ? "Import audio files to start listening" : "Local file from your device");
        }
    }

    private void refreshPlayButton() {
        if (playButton != null) {
            playButton.setText(isPlaying() ? "Pause" : "Play");
        }
    }

    private boolean isPlaying() {
        try {
            return player != null && player.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    private String currentTrackTitle() {
        if (currentIndex >= 0 && currentIndex < tracks.size()) {
            return tracks.get(currentIndex).title;
        }
        return "No track selected";
    }

    private String formatTime(int ms) {
        int total = Math.max(0, ms / 1000);
        int minutes = total / 60;
        int seconds = total % 60;
        return String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    private LinearLayout cardContainer() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(18), dp(18), dp(18));
        box.setBackground(round(card, 28));
        return box;
    }

    private TextView bigText(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(text);
        view.setTextSize(22);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setPadding(0, 0, 0, dp(10));
        return view;
    }

    private TextView normalText(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(muted);
        view.setTextSize(14);
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    private TextView smallText(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(muted);
        view.setTextSize(12);
        return view;
    }

    private TextView bullet(String value) {
        TextView view = normalText("• " + value);
        view.setPadding(0, dp(8), 0, 0);
        return view;
    }

    private Button controlButton(String value) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(value);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setBackground(round(Color.rgb(37, 37, 48), 28));
        addPressAnimation(button);
        return button;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private void addPressAnimation(final View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    view.animate().scaleX(0.97f).scaleY(0.97f).alpha(0.88f).setDuration(90).start();
                } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start();
                }
                return false;
            }
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        super.onDestroy();
    }

    private static class Track {
        final String title;
        final Uri uri;

        Track(String title, Uri uri) {
            this.title = title;
            this.uri = uri;
        }
    }
}
