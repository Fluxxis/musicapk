package com.example.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.example.readyapp.R;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO_REQUEST = 45;
    private static final String PREFS = "ready_music_prefs";
    private static final String PREF_TRACKS = "tracks";

    private final ArrayList<Track> tracks = new ArrayList<Track>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private LinearLayout root;
    private LinearLayout content;
    private TextView libraryTab;
    private TextView importTab;
    private TextView nowTitle;
    private TextView nowSubtitle;
    private TextView bottomTitle;
    private TextView bottomSubtitle;
    private ImageButton playButton;
    private SeekBar progressBar;

    private MediaPlayer mediaPlayer;
    private int selectedIndex = -1;
    private boolean isSeeking = false;
    private boolean showingLibrary = true;

    private final Runnable progressRunnable = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupWindow();
        loadTracks();
        buildUi();
        showLibrary();
        handler.post(progressRunnable);
    }

    private void setupWindow() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            window.setStatusBarColor(Color.rgb(5, 5, 7));
            window.setNavigationBarColor(Color.rgb(5, 5, 7));
        }
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(14));
        root.setBackgroundColor(Color.rgb(5, 5, 7));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        TextView title = text("Music", 34, Color.rgb(247, 247, 250), Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text("Native Java player. Clean iOS-style interface.", 14, Color.rgb(163, 163, 174), Typeface.NORMAL);
        subtitle.setPadding(0, dp(2), 0, dp(14));
        header.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        tabs.setBackground(rounded(Color.rgb(20, 20, 24), dp(18)));
        header.addView(tabs, new LinearLayout.LayoutParams(-1, dp(48)));

        libraryTab = tab("Library");
        importTab = tab("Import");
        tabs.addView(libraryTab, new LinearLayout.LayoutParams(0, -1, 1));
        tabs.addView(importTab, new LinearLayout.LayoutParams(0, -1, 1));

        libraryTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showLibrary();
            }
        });
        importTab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImport();
            }
        });

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(false);
        scrollView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(16), 0, dp(16));
        scrollView.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1));

        root.addView(bottomPlayer(), new LinearLayout.LayoutParams(-1, -2));
    }

    private TextView tab(String value) {
        TextView view = text(value, 15, Color.WHITE, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setClickable(true);
        view.setFocusable(true);
        return view;
    }

    private void showLibrary() {
        showingLibrary = true;
        updateTabs();
        content.removeAllViews();
        content.addView(nowPlayingCard(), new LinearLayout.LayoutParams(-1, -2));
        addGap(content, 14);

        TextView section = text("Songs", 20, Color.rgb(247, 247, 250), Typeface.BOLD);
        content.addView(section, new LinearLayout.LayoutParams(-1, -2));
        addGap(content, 10);

        if (tracks.isEmpty()) {
            content.addView(emptyCard(), new LinearLayout.LayoutParams(-1, -2));
            return;
        }

        for (int i = 0; i < tracks.size(); i++) {
            content.addView(trackRow(i), new LinearLayout.LayoutParams(-1, -2));
            addGap(content, 10);
        }
    }

    private void showImport() {
        showingLibrary = false;
        updateTabs();
        content.removeAllViews();
        content.addView(importCard(), new LinearLayout.LayoutParams(-1, -2));
        addGap(content, 14);
        content.addView(infoCard(), new LinearLayout.LayoutParams(-1, -2));
    }

    private void updateTabs() {
        libraryTab.setBackground(showingLibrary ? rounded(Color.rgb(250, 45, 85), dp(15)) : null);
        importTab.setBackground(!showingLibrary ? rounded(Color.rgb(250, 45, 85), dp(15)) : null);
        libraryTab.setTextColor(showingLibrary ? Color.WHITE : Color.rgb(163, 163, 174));
        importTab.setTextColor(!showingLibrary ? Color.WHITE : Color.rgb(163, 163, 174));
    }

    private View nowPlayingCard() {
        LinearLayout card = card();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));

        FrameLayout cover = new FrameLayout(this);
        GradientDrawable coverBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[] { Color.rgb(250, 45, 85), Color.rgb(255, 106, 136), Color.rgb(32, 32, 38) }
        );
        coverBg.setCornerRadius(dp(28));
        cover.setBackground(coverBg);
        LinearLayout.LayoutParams coverParams = new LinearLayout.LayoutParams(-1, dp(240));
        card.addView(cover, coverParams);

        ImageView note = new ImageView(this);
        note.setImageResource(R.drawable.ic_music_note);
        note.setAlpha(0.9f);
        FrameLayout.LayoutParams noteParams = new FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER);
        cover.addView(note, noteParams);

        addGap(card, 18);
        nowTitle = text(currentTitle(), 25, Color.rgb(247, 247, 250), Typeface.BOLD);
        nowTitle.setMaxLines(2);
        card.addView(nowTitle, new LinearLayout.LayoutParams(-1, -2));

        nowSubtitle = text(currentSubtitle(), 14, Color.rgb(163, 163, 174), Typeface.NORMAL);
        nowSubtitle.setPadding(0, dp(4), 0, 0);
        card.addView(nowSubtitle, new LinearLayout.LayoutParams(-1, -2));

        animateIn(card);
        return card;
    }

    private View emptyCard() {
        LinearLayout card = card();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_library);
        icon.setAlpha(0.72f);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(48), dp(48));
        card.addView(icon, iconParams);

        addGap(card, 14);
        TextView title = text("No songs imported", 19, Color.rgb(247, 247, 250), Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView body = text("Open the Import tab and choose audio files from your device.", 14, Color.rgb(163, 163, 174), Typeface.NORMAL);
        body.setPadding(0, dp(6), 0, dp(16));
        card.addView(body, new LinearLayout.LayoutParams(-1, -2));

        TextView button = primaryButton("Import music");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImport();
            }
        });
        card.addView(button, new LinearLayout.LayoutParams(-1, dp(52)));
        animateIn(card);
        return card;
    }

    private View importCard() {
        LinearLayout card = card();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_import);
        icon.setAlpha(0.9f);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(52), dp(52));
        card.addView(icon, iconParams);

        addGap(card, 14);
        TextView title = text("Import music", 25, Color.rgb(247, 247, 250), Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView body = text("Choose local audio files. The app keeps access through Android document storage and shows them in your library.", 14, Color.rgb(163, 163, 174), Typeface.NORMAL);
        body.setPadding(0, dp(8), 0, dp(18));
        card.addView(body, new LinearLayout.LayoutParams(-1, -2));

        TextView button = primaryButton("Choose audio files");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAudioPicker();
            }
        });
        card.addView(button, new LinearLayout.LayoutParams(-1, dp(54)));
        animateIn(card);
        return card;
    }

    private View infoCard() {
        LinearLayout card = card();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView title = text("Minimal player features", 19, Color.rgb(247, 247, 250), Typeface.BOLD);
        card.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView body = text("• Native Java UI\n• Music import tab\n• Rounded dark cards\n• Bottom mini-player\n• Smooth press and entrance animations\n• No third-party libraries", 14, Color.rgb(190, 190, 198), Typeface.NORMAL);
        body.setPadding(0, dp(10), 0, 0);
        body.setLineSpacing(dp(2), 1.0f);
        card.addView(body, new LinearLayout.LayoutParams(-1, -2));
        animateIn(card);
        return card;
    }

    private View trackRow(final int index) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        row.setBackground(rounded(index == selectedIndex ? Color.rgb(36, 25, 31) : Color.rgb(21, 21, 24), dp(18)));
        row.setClickable(true);
        addPressAnimation(row);

        FrameLayout art = new FrameLayout(this);
        art.setBackground(rounded(Color.rgb(250, 45, 85), dp(15)));
        ImageView note = new ImageView(this);
        note.setImageResource(R.drawable.ic_music_note);
        note.setAlpha(0.9f);
        art.addView(note, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        row.addView(art, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, dp(8), 0);
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        TextView title = text(tracks.get(index).title, 16, Color.rgb(247, 247, 250), Typeface.BOLD);
        title.setSingleLine(true);
        texts.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text(index == selectedIndex ? "Selected" : "Local audio", 13, Color.rgb(163, 163, 174), Typeface.NORMAL);
        subtitle.setPadding(0, dp(3), 0, 0);
        texts.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        ImageView action = new ImageView(this);
        action.setImageResource(index == selectedIndex && isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);
        action.setAlpha(0.95f);
        row.addView(action, new LinearLayout.LayoutParams(dp(30), dp(30)));

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectTrack(index, true);
            }
        });

        animateIn(row);
        return row;
    }

    private View bottomPlayer() {
        LinearLayout player = new LinearLayout(this);
        player.setOrientation(LinearLayout.VERTICAL);
        player.setPadding(dp(14), dp(12), dp(14), dp(12));
        player.setBackground(rounded(Color.rgb(21, 21, 24), dp(24)));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        player.addView(top, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        top.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        bottomTitle = text(currentTitle(), 15, Color.rgb(247, 247, 250), Typeface.BOLD);
        bottomTitle.setSingleLine(true);
        titles.addView(bottomTitle, new LinearLayout.LayoutParams(-1, -2));

        bottomSubtitle = text(currentSubtitle(), 12, Color.rgb(163, 163, 174), Typeface.NORMAL);
        bottomSubtitle.setSingleLine(true);
        titles.addView(bottomSubtitle, new LinearLayout.LayoutParams(-1, -2));

        playButton = new ImageButton(this);
        playButton.setImageResource(R.drawable.ic_play);
        playButton.setBackground(rounded(Color.rgb(250, 45, 85), dp(22)));
        playButton.setPadding(dp(10), dp(10), dp(10), dp(10));
        playButton.setScaleType(ImageView.ScaleType.CENTER);
        addPressAnimation(playButton);
        top.addView(playButton, new LinearLayout.LayoutParams(dp(46), dp(46)));
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                togglePlay();
            }
        });

        addGap(player, 8);
        progressBar = new SeekBar(this);
        progressBar.setMax(1000);
        if (Build.VERSION.SDK_INT >= 21) {
            progressBar.setProgressTintList(ColorStateList.valueOf(Color.rgb(250, 45, 85)));
            progressBar.setThumbTintList(ColorStateList.valueOf(Color.rgb(250, 45, 85)));
            progressBar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(54, 54, 62)));
        }
        progressBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mediaPlayer != null) {
                    int duration = mediaPlayer.getDuration();
                    int position = duration * progress / 1000;
                    mediaPlayer.seekTo(position);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isSeeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                isSeeking = false;
            }
        });
        player.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(34)));
        return player;
    }

    private LinearLayout card() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setBackground(rounded(Color.rgb(21, 21, 24), dp(26)));
        return view;
    }

    private TextView primaryButton(String value) {
        TextView button = text(value, 16, Color.WHITE, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setBackground(rounded(Color.rgb(250, 45, 85), dp(18)));
        button.setClickable(true);
        addPressAnimation(button);
        return button;
    }

    private TextView text(String value, int sp, int color, int style) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, style);
        view.setIncludeFontPadding(true);
        return view;
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private void addGap(LinearLayout parent, int dpValue) {
        Space space = new Space(this);
        parent.addView(space, new LinearLayout.LayoutParams(1, dp(dpValue)));
    }

    private void animateIn(View view) {
        view.setAlpha(0f);
        view.setTranslationY(dp(12));
        view.animate().alpha(1f).translationY(0f).setDuration(260).start();
    }

    private void addPressAnimation(final View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View touched, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    touched.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
                    touched.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    touched.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                }
                return false;
            }
        });
    }

    private void openAudioPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_AUDIO_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_AUDIO_REQUEST || resultCode != RESULT_OK || data == null) {
            return;
        }

        int added = 0;
        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int i = 0; i < clipData.getItemCount(); i++) {
                Uri uri = clipData.getItemAt(i).getUri();
                if (addTrackFromUri(uri, data.getFlags())) {
                    added++;
                }
            }
        } else if (data.getData() != null) {
            if (addTrackFromUri(data.getData(), data.getFlags())) {
                added++;
            }
        }

        if (added > 0) {
            saveTracks();
            Toast.makeText(this, String.format(Locale.US, "Imported %d track(s)", added), Toast.LENGTH_SHORT).show();
            selectedIndex = tracks.size() - 1;
            updatePlayerText();
            showLibrary();
        }
    }

    private boolean addTrackFromUri(Uri uri, int flags) {
        if (uri == null) {
            return false;
        }
        try {
            int takeFlags = flags & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (takeFlags != 0) {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
        } catch (Exception ignored) {
        }

        String uriText = uri.toString();
        for (int i = 0; i < tracks.size(); i++) {
            if (tracks.get(i).uri.equals(uriText)) {
                return false;
            }
        }
        tracks.add(new Track(uriText, readName(uri)));
        return true;
    }

    private String readName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    String name = cursor.getString(index);
                    if (name != null && name.trim().length() > 0) {
                        return name;
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        String fallback = uri.getLastPathSegment();
        return fallback == null ? "Audio file" : fallback;
    }

    private void selectTrack(int index, boolean startPlayback) {
        if (index < 0 || index >= tracks.size()) {
            return;
        }
        selectedIndex = index;
        updatePlayerText();
        preparePlayer(startPlayback);
        if (showingLibrary) {
            showLibrary();
        }
    }

    private void preparePlayer(boolean startPlayback) {
        releasePlayer();
        if (selectedIndex < 0 || selectedIndex >= tracks.size()) {
            return;
        }
        try {
            mediaPlayer = MediaPlayer.create(this, Uri.parse(tracks.get(selectedIndex).uri));
            if (mediaPlayer == null) {
                Toast.makeText(this, "Cannot open this audio file", Toast.LENGTH_SHORT).show();
                return;
            }
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer player) {
                    updatePlayIcon();
                    progressBar.setProgress(0);
                }
            });
            if (startPlayback) {
                mediaPlayer.start();
            }
            updatePlayIcon();
        } catch (Exception exception) {
            Toast.makeText(this, "Playback error", Toast.LENGTH_SHORT).show();
            releasePlayer();
        }
    }

    private void togglePlay() {
        if (selectedIndex < 0) {
            if (tracks.isEmpty()) {
                showImport();
                return;
            }
            selectedIndex = 0;
            updatePlayerText();
        }
        if (mediaPlayer == null) {
            preparePlayer(true);
            return;
        }
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        } else {
            mediaPlayer.start();
        }
        updatePlayIcon();
        if (showingLibrary) {
            showLibrary();
        }
    }

    private void updatePlayerText() {
        if (bottomTitle != null) {
            bottomTitle.setText(currentTitle());
        }
        if (bottomSubtitle != null) {
            bottomSubtitle.setText(currentSubtitle());
        }
        if (nowTitle != null) {
            nowTitle.setText(currentTitle());
        }
        if (nowSubtitle != null) {
            nowSubtitle.setText(currentSubtitle());
        }
    }

    private void updatePlayIcon() {
        if (playButton != null) {
            playButton.setImageResource(isPlaying() ? R.drawable.ic_pause : R.drawable.ic_play);
        }
    }

    private boolean isPlaying() {
        return mediaPlayer != null && mediaPlayer.isPlaying();
    }

    private String currentTitle() {
        if (selectedIndex >= 0 && selectedIndex < tracks.size()) {
            return tracks.get(selectedIndex).title;
        }
        return tracks.isEmpty() ? "Ready Music" : "Select a song";
    }

    private String currentSubtitle() {
        if (selectedIndex >= 0 && selectedIndex < tracks.size()) {
            return isPlaying() ? "Playing now" : "Ready to play";
        }
        return tracks.isEmpty() ? "Import music to start" : tracks.size() + " track(s) in library";
    }

    private void updateProgress() {
        if (progressBar == null || mediaPlayer == null || isSeeking) {
            return;
        }
        try {
            int duration = mediaPlayer.getDuration();
            if (duration <= 0) {
                progressBar.setProgress(0);
                return;
            }
            int position = mediaPlayer.getCurrentPosition();
            progressBar.setProgress(position * 1000 / duration);
        } catch (Exception ignored) {
        }
    }

    private void releasePlayer() {
        if (mediaPlayer != null) {
            try {
                mediaPlayer.release();
            } catch (Exception ignored) {
            }
            mediaPlayer = null;
        }
        updatePlayIcon();
    }

    private void loadTracks() {
        SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String saved = prefs.getString(PREF_TRACKS, "");
        if (saved == null || saved.length() == 0) {
            return;
        }
        String[] lines = saved.split("\\n");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.trim().length() == 0) {
                continue;
            }
            String[] parts = line.split("\\t", 2);
            if (parts.length == 2) {
                tracks.add(new Track(Uri.decode(parts[0]), Uri.decode(parts[1])));
            }
        }
    }

    private void saveTracks() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < tracks.size(); i++) {
            Track track = tracks.get(i);
            builder.append(Uri.encode(track.uri));
            builder.append('\t');
            builder.append(Uri.encode(track.title));
            builder.append('\n');
        }
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(PREF_TRACKS, builder.toString()).apply();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        super.onDestroy();
    }

    private static class Track {
        final String uri;
        final String title;

        Track(String uri, String title) {
            this.uri = uri;
            this.title = title;
        }
    }
}
