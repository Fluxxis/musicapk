# Ready Music Android Java Project

Простой нативный Android-проект на Java без Gradle и Android Studio.

## Сборка

```bash
chmod +x build.sh
./build.sh
```

После сборки готовый APK будет здесь:

```bash
dist/app-release.apk
```
