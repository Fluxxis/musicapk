Ready Android App

Simple native Android Java project.
No Android Studio.
No Gradle.
No third-party libraries.

Build commands:

chmod +x build.sh
./build.sh

After build:

dist/app-release.apk
