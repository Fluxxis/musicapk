#!/bin/sh

# Self-contained Android APK builder.
# Keep this script portable: no Gradle, no Android Studio, no Bash-only syntax.

# First run: restart in a clean environment. This avoids broken server shell startup
# files like /etc/shellrc when child tools start shell scripts under nounset.
if [ "${READY_BUILD_CLEAN_ENV:-}" != "1" ]; then
    ORIGINAL_PATH="${PATH:-/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin}"
    exec env -i \
        READY_BUILD_CLEAN_ENV=1 \
        NOCOLOR=1 \
        NO_COLOR=1 \
        TERM=dumb \
        SHELL=/bin/sh \
        PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$ORIGINAL_PATH" \
        HOME="${HOME:-/tmp}" \
        USER="${USER:-root}" \
        LOGNAME="${LOGNAME:-${USER:-root}}" \
        JAVA_HOME="${JAVA_HOME:-}" \
        ANDROID_HOME="${ANDROID_HOME:-}" \
        ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-}" \
        HTTP_PROXY="${HTTP_PROXY:-}" \
        HTTPS_PROXY="${HTTPS_PROXY:-}" \
        NO_PROXY="${NO_PROXY:-}" \
        http_proxy="${http_proxy:-}" \
        https_proxy="${https_proxy:-}" \
        no_proxy="${no_proxy:-}" \
        SSL_CERT_FILE="${SSL_CERT_FILE:-}" \
        SSL_CERT_DIR="${SSL_CERT_DIR:-}" \
        LANG="${LANG:-C.UTF-8}" \
        LC_ALL="${LC_ALL:-}" \
        /bin/sh "$0" "$@"
fi

set -e

PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$PROJECT_DIR"

APP_ID="com.example.readyapp"
MIN_SDK="23"
TARGET_SDK="35"
COMPILE_SDK="35"
BUILD_TOOLS_VERSION="35.0.0"
CMDLINE_TOOLS_VERSION="14742923"
CMDLINE_TOOLS_ZIP="commandlinetools-linux-${CMDLINE_TOOLS_VERSION}_latest.zip"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/${CMDLINE_TOOLS_ZIP}"

BUILD_DIR="$PROJECT_DIR/build"
DIST_DIR="$PROJECT_DIR/dist"
LOCAL_SDK="$PROJECT_DIR/.android-sdk"

log() {
    printf '%s\n' "[build] $*"
}

fail() {
    printf '%s\n' "[build] ERROR: $*" >&2
    exit 1
}

need_cmd() {
    command -v "$1" >/dev/null 2>&1 || fail "Missing command: $1"
}

clean_run() {
    env -i \
        READY_BUILD_CLEAN_ENV=1 \
        NOCOLOR=1 \
        NO_COLOR=1 \
        TERM=dumb \
        SHELL=/bin/sh \
        PATH="${PATH:-/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin}" \
        HOME="${HOME:-/tmp}" \
        USER="${USER:-root}" \
        LOGNAME="${LOGNAME:-${USER:-root}}" \
        JAVA_HOME="${JAVA_HOME:-}" \
        ANDROID_HOME="${ANDROID_HOME:-}" \
        ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-}" \
        HTTP_PROXY="${HTTP_PROXY:-}" \
        HTTPS_PROXY="${HTTPS_PROXY:-}" \
        NO_PROXY="${NO_PROXY:-}" \
        http_proxy="${http_proxy:-}" \
        https_proxy="${https_proxy:-}" \
        no_proxy="${no_proxy:-}" \
        SSL_CERT_FILE="${SSL_CERT_FILE:-}" \
        SSL_CERT_DIR="${SSL_CERT_DIR:-}" \
        LANG="${LANG:-C.UTF-8}" \
        LC_ALL="${LC_ALL:-}" \
        "$@"
}

java_major() {
    clean_run java -version 2>&1 | awk -F '"' '/version/ {print $2}' | awk -F. '{ if ($1 == "1") print $2; else print $1 }'
}

check_java() {
    need_cmd java
    need_cmd javac
    need_cmd jar
    need_cmd keytool
    MAJOR=$(java_major)
    case "$MAJOR" in
        ''|*[!0-9]*) fail "Cannot detect Java version" ;;
    esac
    if [ "$MAJOR" -lt 17 ]; then
        fail "Java 17+ required. Found Java $MAJOR"
    fi
    JAVA_VERSION=$(clean_run java -version 2>&1 | awk -F '"' '/version/ {print $2; exit}')
    log "Java OK: $JAVA_VERSION"
}

detect_sdk_root() {
    if [ -n "${ANDROID_HOME:-}" ] && [ -d "$ANDROID_HOME" ]; then
        SDK_ROOT="$ANDROID_HOME"
    elif [ -n "${ANDROID_SDK_ROOT:-}" ] && [ -d "$ANDROID_SDK_ROOT" ]; then
        SDK_ROOT="$ANDROID_SDK_ROOT"
    else
        SDK_ROOT="$LOCAL_SDK"
    fi
    ANDROID_HOME="$SDK_ROOT"
    ANDROID_SDK_ROOT="$SDK_ROOT"
    export ANDROID_HOME ANDROID_SDK_ROOT SDK_ROOT
}

download_cmdline_tools_with_python() {
    need_cmd python3
    DEST="$SDK_ROOT/cmdline-tools/latest"
    clean_run python3 - "$CMDLINE_TOOLS_URL" "$DEST" <<'PY'
import os
import shutil
import sys
import tempfile
import urllib.request
import zipfile

url = sys.argv[1]
dest = sys.argv[2]
root = os.path.dirname(dest)
os.makedirs(root, exist_ok=True)
work = tempfile.mkdtemp(prefix="android-cmdline-tools-")
zip_path = os.path.join(work, "tools.zip")
try:
    req = urllib.request.Request(url, headers={"User-Agent": "ready-android-app-builder/1.0"})
    with urllib.request.urlopen(req, timeout=90) as response, open(zip_path, "wb") as output:
        shutil.copyfileobj(response, output)
    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(work)
    extracted = os.path.join(work, "cmdline-tools")
    if not os.path.isdir(extracted):
        raise RuntimeError("cmdline-tools folder not found in downloaded ZIP")
    if os.path.exists(dest):
        shutil.rmtree(dest)
    shutil.move(extracted, dest)
finally:
    shutil.rmtree(work, ignore_errors=True)
PY
}

install_cmdline_tools() {
    log "Android SDK not found. Downloading Android command-line tools."
    mkdir -p "$SDK_ROOT/cmdline-tools"
    download_cmdline_tools_with_python
}

ensure_sdk() {
    detect_sdk_root
    SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
    if [ ! -x "$SDKMANAGER" ]; then
        install_cmdline_tools
    fi
    SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
    [ -x "$SDKMANAGER" ] || fail "sdkmanager not found after install"

    log "Installing Android SDK packages."
    yes | clean_run "$SDKMANAGER" --sdk_root="$SDK_ROOT" --licenses >/dev/null 2>&1 || true
    yes | clean_run "$SDKMANAGER" --sdk_root="$SDK_ROOT" \
        "platform-tools" \
        "build-tools;$BUILD_TOOLS_VERSION" \
        "platforms;android-$COMPILE_SDK" >/dev/null

    AAPT2="$SDK_ROOT/build-tools/$BUILD_TOOLS_VERSION/aapt2"
    D8="$SDK_ROOT/build-tools/$BUILD_TOOLS_VERSION/d8"
    ZIPALIGN="$SDK_ROOT/build-tools/$BUILD_TOOLS_VERSION/zipalign"
    APKSIGNER="$SDK_ROOT/build-tools/$BUILD_TOOLS_VERSION/apksigner"
    ANDROID_JAR="$SDK_ROOT/platforms/android-$COMPILE_SDK/android.jar"

    [ -x "$AAPT2" ] || fail "aapt2 not found"
    [ -x "$D8" ] || fail "d8 not found"
    [ -x "$ZIPALIGN" ] || fail "zipalign not found"
    [ -x "$APKSIGNER" ] || fail "apksigner not found"
    [ -f "$ANDROID_JAR" ] || fail "android.jar not found"
    log "Android SDK OK: $SDK_ROOT"
}

clean_build() {
    rm -rf "$BUILD_DIR" "$DIST_DIR"
    mkdir -p "$BUILD_DIR/res" "$BUILD_DIR/gen" "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$DIST_DIR"
}

compile_resources() {
    log "Compiling resources with aapt2."
    clean_run "$AAPT2" compile --dir "$PROJECT_DIR/res" -o "$BUILD_DIR/compiled_res.zip"

    log "Linking resources."
    clean_run "$AAPT2" link \
        -I "$ANDROID_JAR" \
        --manifest "$PROJECT_DIR/AndroidManifest.xml" \
        --java "$BUILD_DIR/gen" \
        --min-sdk-version "$MIN_SDK" \
        --target-sdk-version "$TARGET_SDK" \
        --version-code 1 \
        --version-name 1.0 \
        --auto-add-overlay \
        -o "$BUILD_DIR/resources.apk" \
        "$BUILD_DIR/compiled_res.zip"
}

compile_java() {
    log "Compiling Java code."
    find "$PROJECT_DIR/src" "$BUILD_DIR/gen" -name '*.java' > "$BUILD_DIR/sources.txt"
    [ -s "$BUILD_DIR/sources.txt" ] || fail "No Java sources found"
    clean_run javac -encoding UTF-8 -source 8 -target 8 -Xlint:none \
        -classpath "$ANDROID_JAR" \
        -d "$BUILD_DIR/classes" \
        @"$BUILD_DIR/sources.txt"

    clean_run jar cf "$BUILD_DIR/classes.jar" -C "$BUILD_DIR/classes" .
}

build_dex() {
    log "Converting Java bytecode with D8."
    clean_run "$D8" --release --min-api "$MIN_SDK" --lib "$ANDROID_JAR" \
        --output "$BUILD_DIR/dex" \
        "$BUILD_DIR/classes.jar"
    [ -f "$BUILD_DIR/dex/classes.dex" ] || fail "D8 did not create classes.dex"
}

package_unsigned_apk() {
    log "Creating unsigned APK."
    cp "$BUILD_DIR/resources.apk" "$BUILD_DIR/app-unsigned.apk"
    (cd "$BUILD_DIR/dex" && clean_run zip -q -u "$BUILD_DIR/app-unsigned.apk" classes.dex)
    [ -f "$BUILD_DIR/app-unsigned.apk" ] || fail "Unsigned APK was not created"
}

ensure_keystore() {
    KEYSTORE="$PROJECT_DIR/debug.keystore"
    if [ ! -f "$KEYSTORE" ]; then
        log "Creating debug keystore."
        clean_run keytool -genkeypair \
            -keystore "$KEYSTORE" \
            -storepass android \
            -keypass android \
            -alias androiddebugkey \
            -keyalg RSA \
            -keysize 2048 \
            -validity 10000 \
            -dname "CN=Android Debug,O=Android,C=US" >/dev/null
    fi
}

sign_apk() {
    log "Aligning APK."
    clean_run "$ZIPALIGN" -p -f 4 "$BUILD_DIR/app-unsigned.apk" "$BUILD_DIR/app-aligned.apk"

    log "Signing APK."
    clean_run "$APKSIGNER" sign \
        --ks "$KEYSTORE" \
        --ks-pass pass:android \
        --key-pass pass:android \
        --out "$DIST_DIR/app-release.apk" \
        "$BUILD_DIR/app-aligned.apk"

    log "Verifying signature."
    clean_run "$APKSIGNER" verify --verbose "$DIST_DIR/app-release.apk" >/dev/null
    [ -f "$DIST_DIR/app-release.apk" ] || fail "Final APK missing"
}

main() {
    check_java
    ensure_sdk
    clean_build
    compile_resources
    compile_java
    build_dex
    package_unsigned_apk
    ensure_keystore
    sign_apk
    log "Done: dist/app-release.apk"
}

main "$@"
