#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

APP_PACKAGE="com.example.readyapp"
MIN_SDK="23"
TARGET_SDK="35"
COMPILE_SDK="35"
BUILD_TOOLS_VERSION="35.0.0"

BUILD_DIR="$ROOT_DIR/build"
DIST_DIR="$ROOT_DIR/dist"
KEYSTORE="$ROOT_DIR/debug.keystore"

log() {
  printf '\033[1;32m[build]\033[0m %s\n' "$1"
}

fail() {
  printf '\033[1;31m[error]\033[0m %s\n' "$1" >&2
  exit 1
}

ensure_host_tool() {
  local name="$1"
  local package_name="${2:-$1}"
  if command -v "$name" >/dev/null 2>&1; then
    return 0
  fi

  log "Installing host dependency: $package_name"
  if command -v apt-get >/dev/null 2>&1; then
    if [ "$(id -u)" = "0" ]; then
      apt-get update
      DEBIAN_FRONTEND=noninteractive apt-get install -y "$package_name"
    elif command -v sudo >/dev/null 2>&1; then
      sudo apt-get update
      sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "$package_name"
    else
      fail "Missing $name and sudo is not available. Install $package_name and run ./build.sh again."
    fi
  else
    fail "Missing $name. Install $package_name and run ./build.sh again."
  fi
}

check_java_17() {
  command -v java >/dev/null 2>&1 || fail "Java is missing. Install JDK 17 or newer."
  command -v javac >/dev/null 2>&1 || fail "javac is missing. Install full JDK 17 or newer, not only JRE."
  command -v keytool >/dev/null 2>&1 || fail "keytool is missing. Install full JDK 17 or newer."

  local version
  version="$(java -version 2>&1 | awk -F '"' '/version/ {print $2; exit}')"
  [ -n "$version" ] || fail "Cannot read Java version."

  local major
  if [[ "$version" == 1.* ]]; then
    major="$(printf '%s' "$version" | cut -d. -f2)"
  else
    major="$(printf '%s' "$version" | cut -d. -f1)"
  fi

  if [ "$major" -lt 17 ]; then
    fail "Java $version found. JDK 17 or newer is required."
  fi
  log "Java OK: $version"
}

resolve_android_home() {
  if [ -n "${ANDROID_HOME:-}" ]; then
    printf '%s' "$ANDROID_HOME"
  elif [ -n "${ANDROID_SDK_ROOT:-}" ]; then
    printf '%s' "$ANDROID_SDK_ROOT"
  else
    printf '%s' "$HOME/Android/Sdk"
  fi
}

find_sdkmanager() {
  local sdk_dir="$1"
  local sdkmanager_path=""

  if [ -x "$sdk_dir/cmdline-tools/latest/bin/sdkmanager" ]; then
    sdkmanager_path="$sdk_dir/cmdline-tools/latest/bin/sdkmanager"
  elif [ -x "$sdk_dir/tools/bin/sdkmanager" ]; then
    sdkmanager_path="$sdk_dir/tools/bin/sdkmanager"
  else
    sdkmanager_path="$(find "$sdk_dir/cmdline-tools" -path '*/bin/sdkmanager' -type f 2>/dev/null | sort | tail -n 1 || true)"
  fi

  printf '%s' "$sdkmanager_path"
}

download_cmdline_tools() {
  local sdk_dir="$1"
  local tmp_dir
  tmp_dir="$(mktemp -d)"
  mkdir -p "$sdk_dir/cmdline-tools"

  log "Android SDK not found. Downloading Android command-line tools."

  local repo_xml="$tmp_dir/repository2-1.xml"
  local tools_url=""
  curl -fsSL "https://dl.google.com/android/repository/repository2-1.xml" -o "$repo_xml" || true

  if command -v python3 >/dev/null 2>&1 && [ -s "$repo_xml" ]; then
    tools_url="$(python3 - "$repo_xml" <<'PY'
import sys
import xml.etree.ElementTree as ET

repo = sys.argv[1]
root = ET.parse(repo).getroot()
items = []
for pkg in root.findall('.//remotePackage'):
    path = pkg.attrib.get('path', '')
    if not (path == 'cmdline-tools;latest' or path.startswith('cmdline-tools;')):
        continue
    revision = pkg.find('revision')
    if revision is None:
        score = (0, 0, 0)
    else:
        score = tuple(int(revision.findtext(x) or 0) for x in ('major', 'minor', 'micro'))
    for archive in pkg.findall('.//archive'):
        if archive.findtext('host-os') == 'linux':
            url = archive.findtext('complete/url')
            if url:
                priority = 1 if path == 'cmdline-tools;latest' else 0
                items.append((priority, score, url))
if not items:
    raise SystemExit(1)
items.sort()
print(items[-1][2])
PY
)" || true
  fi

  if [ -z "$tools_url" ]; then
    tools_url="commandlinetools-linux-11076708_latest.zip"
  fi

  if [[ "$tools_url" != https://* ]]; then
    tools_url="https://dl.google.com/android/repository/$tools_url"
  fi

  log "Command-line tools URL: $tools_url"
  curl -fL "$tools_url" -o "$tmp_dir/cmdline-tools.zip"

  unzip -q "$tmp_dir/cmdline-tools.zip" -d "$tmp_dir/unpacked"
  rm -rf "$sdk_dir/cmdline-tools/latest"
  mkdir -p "$sdk_dir/cmdline-tools/latest"

  if [ -d "$tmp_dir/unpacked/cmdline-tools" ]; then
    shopt -s dotglob
    mv "$tmp_dir/unpacked/cmdline-tools"/* "$sdk_dir/cmdline-tools/latest/"
    shopt -u dotglob
  else
    shopt -s dotglob
    mv "$tmp_dir/unpacked"/* "$sdk_dir/cmdline-tools/latest/"
    shopt -u dotglob
  fi

  rm -rf "$tmp_dir"
}

install_android_packages() {
  local sdk_dir="$1"
  export ANDROID_HOME="$sdk_dir"
  export ANDROID_SDK_ROOT="$sdk_dir"
  export PATH="$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"

  local sdkmanager_path
  sdkmanager_path="$(find_sdkmanager "$sdk_dir")"
  if [ -z "$sdkmanager_path" ]; then
    download_cmdline_tools "$sdk_dir"
    sdkmanager_path="$(find_sdkmanager "$sdk_dir")"
  fi

  [ -x "$sdkmanager_path" ] || fail "sdkmanager was not found after installing command-line tools."

  log "Accepting Android SDK licenses"
  yes | "$sdkmanager_path" --sdk_root="$sdk_dir" --licenses >/dev/null || true

  log "Installing Android SDK packages"
  "$sdkmanager_path" --sdk_root="$sdk_dir" --install \
    "platform-tools" \
    "build-tools;$BUILD_TOOLS_VERSION" \
    "platforms;android-$COMPILE_SDK"
}

build_apk() {
  local sdk_dir="$1"
  local build_tools="$sdk_dir/build-tools/$BUILD_TOOLS_VERSION"
  local android_jar="$sdk_dir/platforms/android-$COMPILE_SDK/android.jar"
  local aapt2="$build_tools/aapt2"
  local d8="$build_tools/d8"
  local zipalign="$build_tools/zipalign"
  local apksigner="$build_tools/apksigner"

  [ -f "$android_jar" ] || fail "Missing $android_jar"
  [ -x "$aapt2" ] || fail "Missing aapt2"
  [ -x "$d8" ] || fail "Missing d8"
  [ -x "$zipalign" ] || fail "Missing zipalign"
  [ -x "$apksigner" ] || fail "Missing apksigner"

  rm -rf "$BUILD_DIR" "$DIST_DIR"
  mkdir -p "$BUILD_DIR/compiled" "$BUILD_DIR/generated" "$BUILD_DIR/classes" "$BUILD_DIR/dex" "$DIST_DIR"

  log "Compiling resources with aapt2"
  "$aapt2" compile --dir "$ROOT_DIR/res" -o "$BUILD_DIR/compiled/resources.zip"

  log "Linking unsigned APK"
  "$aapt2" link \
    -o "$BUILD_DIR/app-unsigned-unaligned.apk" \
    -I "$android_jar" \
    --manifest "$ROOT_DIR/AndroidManifest.xml" \
    --java "$BUILD_DIR/generated" \
    --min-sdk-version "$MIN_SDK" \
    --target-sdk-version "$TARGET_SDK" \
    "$BUILD_DIR/compiled/resources.zip"

  log "Compiling Java sources"
  find "$ROOT_DIR/src" "$BUILD_DIR/generated" -name '*.java' | sort > "$BUILD_DIR/sources.txt"
  javac \
    -encoding UTF-8 \
    -source 1.8 \
    -target 1.8 \
    -Xlint:-options \
    -bootclasspath "$android_jar" \
    -classpath "$android_jar" \
    -d "$BUILD_DIR/classes" \
    @"$BUILD_DIR/sources.txt"

  log "Converting classes to DEX"
  mapfile -t class_files < <(find "$BUILD_DIR/classes" -name '*.class' | sort)
  if [ "${#class_files[@]}" -eq 0 ]; then
    fail "No compiled .class files found."
  fi
  "$d8" \
    --min-api "$MIN_SDK" \
    --lib "$android_jar" \
    --output "$BUILD_DIR/dex" \
    "${class_files[@]}"

  log "Packaging unsigned APK"
  cp "$BUILD_DIR/app-unsigned-unaligned.apk" "$BUILD_DIR/app-with-dex-unaligned.apk"
  (cd "$BUILD_DIR/dex" && zip -q -r "$BUILD_DIR/app-with-dex-unaligned.apk" .)

  if [ ! -f "$KEYSTORE" ]; then
    log "Creating debug keystore"
    keytool -genkeypair \
      -keystore "$KEYSTORE" \
      -storepass android \
      -keypass android \
      -alias androiddebugkey \
      -keyalg RSA \
      -keysize 2048 \
      -validity 10000 \
      -dname "CN=Android Debug,O=Android,C=US" >/dev/null
  fi

  log "Aligning APK"
  "$zipalign" -p -f 4 "$BUILD_DIR/app-with-dex-unaligned.apk" "$BUILD_DIR/app-aligned.apk"

  log "Signing APK"
  "$apksigner" sign \
    --ks "$KEYSTORE" \
    --ks-pass pass:android \
    --key-pass pass:android \
    --out "$DIST_DIR/app-release.apk" \
    "$BUILD_DIR/app-aligned.apk"

  log "Verifying APK signature"
  "$apksigner" verify --verbose --print-certs "$DIST_DIR/app-release.apk"

  log "Done: dist/app-release.apk"
}

main() {
  check_java_17
  ensure_host_tool curl curl
  ensure_host_tool unzip unzip
  ensure_host_tool zip zip

  local sdk_dir
  sdk_dir="$(resolve_android_home)"
  mkdir -p "$sdk_dir"
  install_android_packages "$sdk_dir"
  build_apk "$sdk_dir"
}

main "$@"
